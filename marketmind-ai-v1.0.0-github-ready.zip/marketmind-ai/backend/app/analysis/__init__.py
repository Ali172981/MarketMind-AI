"""Deterministic market-analysis engines."""
