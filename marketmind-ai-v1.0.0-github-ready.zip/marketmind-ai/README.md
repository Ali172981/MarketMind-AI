# MarketMind AI v1.0.0 — Final Research Platform Release

MarketMind AI is a research-first market intelligence workspace for crypto and indicative precious-metals context. The 1.0.0 release freezes feature development and consolidates the v0.19.0 platform. It includes market data, SMC analysis, backtesting, strict walk-forward diagnostics, prospective paper research, portfolio scenarios, news context, provider quality checks, order-book snapshot analytics and operational tooling.

**This is not an automated trading product.** It does not place orders, guarantee fills, promise returns or authorize live trading. Probabilities remain suppressed unless all predeclared historical validation gates pass; even a historical pass does not enable live probabilities. Provider credentials and live feed availability must be verified by the operator.

Start with [`INSTALL-KALI.md`](INSTALL-KALI.md), then run `python scripts_preflight.py` from `backend/`. See [`docs/FINAL-RELEASE.md`](docs/FINAL-RELEASE.md) and [`docs/OPERATIONS-RUNBOOK.md`](docs/OPERATIONS-RUNBOOK.md) for acceptance criteria and operations.

## New in v0.18.0 — Cross-provider validation & sampled tick archive

- In AllTick mode, independent Binance Spot crypto and XAUS indicative metals feeds provide reference quotes.
- Compares AllTick and reference prices using freshness, absolute deviation in basis points, and source timestamp skew.
- Persists sampled AllTick trade ticks or order-book midpoints to SQLite with per-symbol sampling and configurable retention.
- Adds `/api/v1/market/data-quality`, `/api/v1/market/data-quality/comparisons`, and `/api/v1/market/data-quality/observations`, plus a dashboard comparison panel.
- Screening thresholds are heuristic. Crypto venues can differ; XAUS metals are indicative spot references, not executable broker quotes. Provider candle histories remain separate and no trading or probability eligibility changes.

## New in v0.17.0 — AllTick WebSocket streaming and data quality

- Added opt-in AllTick WebSocket trade-tick and order-book streaming, plus REST quote and K-line support for crypto and precious metals, alongside Binance and demo providers.
- Added server-side API-token configuration, ten-second application heartbeats, bounded reconnect, stale-feed diagnostics, quote sequence checks, provider status and provider-separated candle storage.
- Added AllTick-aware candle, SMC, backtest and research routes, a stream monitor in the dashboard and `/api/v1/market/stream`; prospective paper execution remains Binance-only.
- See the AllTick section below and `INSTALL-KALI.md` for token setup, symbol caveats, quotas and data-quality limitations.

## New in v0.15.0 — Milestone 14 news intelligence

- Public RSS ingestion from CoinDesk, Cointelegraph and Federal Reserve press releases; feed failures are isolated and visible.
- Source headline, source URL, source publication timestamp and separate ingestion timestamp are retained.
- Duplicate headlines are suppressed by normalized-title hash; tracking query parameters are stripped from stored links.
- Transparent keyword event categories, affected-asset tags, and a heuristic review-priority label. Directional bias is always `UNASSESSED`; no sentiment or trade signal is inferred.
- Descriptive pre/post closed-candle returns around publication time, clearly labelled temporal association rather than causality.
- API endpoints: `GET /api/v1/news`, `GET /api/v1/news/status`, `POST /api/v1/news/refresh`, and `GET /api/v1/news/{id}/market-reaction`. Manual refresh is subject to the configured write API key.
- News ingestion can be disabled with `NEWS_ENABLED=false`; refresh cadence is configurable with `NEWS_POLL_SECONDS`. RSS availability and publisher timestamps are not guaranteed.

## New in v0.14.0 — Milestone 13 operational reliability

- Detailed operational diagnostics for SQLite integrity/connectivity, Binance WebSocket state, stored candle freshness, and disk capacity.
- Optional Telegram and SMTP email alerts with per-issue cooldown and recovery reset.
- API-key protection for write requests when configured, production startup guard, and a single-process per-IP write limiter.
- Verified online SQLite backup script with integrity checking, atomic publication, and retention.
- systemd API service and backup timer templates plus a Caddy HTTPS reverse-proxy example.
- Operational monitoring does not alter research calculations or enable live trading. See `INSTALL-KALI.md` for setup and deployment limitations.

## Existing project capabilities

- FastAPI backend and Next.js dashboard.
- Binance public Spot market ticker and kline REST/WebSocket feeds for BTCUSDT, ETHUSDT, and SOLUSDT.
- Local SQLite OHLCV store.
- Deterministic confirmed swing, BOS/CHoCH, liquidity pool/sweep, FVG, and candidate order-block annotations.
- Initial SMC next-candle backtest with configurable costs and conservative same-bar stop-first handling.
- Free indicative metals quote and public macro observations from the earlier data milestone; source/freshness caveats remain visible.
- News intelligence uses allowlisted public RSS sources; it is not a comprehensive or guaranteed real-time news service.

## New in v0.8.0 — Milestone 7

1. **Five expanding-window folds** — 35% initial training window, a 15% calibration window, a 10% test window, and 10-percentage-point expanding steps. Test periods are chronological and non-overlapping.
2. **Leakage controls** — 48-candle embargoes after training and calibration boundaries, plus purging of any label whose outcome window crosses its segment boundary.
3. **Predeclared performance gates** — all folds must meet sample and class-balance minima; at least four of five folds must beat the fold-specific training-rate baseline on Brier score; pooled Brier and log loss must beat that baseline; the Platt slope must be positive in every fold.
4. **Dependence-aware uncertainty** — a 95% moving-block bootstrap interval for pooled Brier skill must have a lower bound above zero. ECE and trend and volatility regime-slice checks must also pass.
5. **Automatic probability suppression** — when any strict gate fails, the API returns no per-event probabilities. Aggregate fold diagnostics and failure reasons remain visible. On a historical pass, historical OOS estimates may be shown, but live signal eligibility remains disabled.
6. **Transparent dashboard** — fold counts, Platt slopes, baseline comparisons, bootstrap interval, regime metrics and gate failures are displayed.


## New in v0.9.0 — Milestone 8 diagnostics and prospective observations

1. **Outcome and score-direction audit** — verifies that `TARGET` is the positive class, reports training/calibration/test ROC AUC and Platt slopes, and never reverses scores based on test outcomes.
2. **Feature investigation** — selects each feature's orientation on the training partition only, then measures that fixed orientation on test data; reports feature distribution shifts and standardized full-model coefficients.
3. **Transparent challenger benchmarks** — compares constant training prevalence, direction-frequency and event-type-frequency baselines with the existing SMC logistic model on identical OOS events. These are diagnostic only; selecting a challenger on the same test folds is prohibited.
4. **Prospective paper observation recorder** — captures confirmed structure events on the latest closed candle, tracks a hypothetical next-open entry against fixed stop/target/horizon rules as future bars arrive, and records STOP/TARGET/TIMEOUT outcomes using conservative same-bar STOP-first handling.
5. **No execution or probability leakage** — paper observation records contain no probabilities or orders. The optional scheduler is disabled by default and must be explicitly enabled. Strict probability suppression and disabled live signal eligibility remain in force.



## New in v0.10.0 — Milestone 9 scheduled observation capture

- Optional FastAPI-lifespan worker, disabled by default and enabled only when `PAPER_RECORDER_ENABLED=true` and `DATA_MODE=binance`.
- Configurable symbol/timeframe pairs (default BTCUSDT, ETHUSDT and SOLUSDT on 1h), polling interval and candle lookback.
- Filters incomplete candles, rejects non-Binance sources, enforces a minimum closed-candle history and skips stale latest candles.
- Advances previous records and captures the latest confirmed structure event on each cycle; one market failing does not stop other pairs.
- Persists per-cycle status, counts, errors and raw pair diagnostics in SQLite. Read status at `/api/v1/market/research/paper/automation/status` and history at `/api/v1/market/research/paper/automation/runs`.
- Run one Uvicorn worker process while enabled. This is not a distributed scheduler; a future multi-replica deployment needs a scheduler lock/leader mechanism.
- The collector records prospective observations and, from v0.11.0, a separate deterministic cost-aware OHLC execution scenario. It has no probabilities, broker-connected fills, live signals or orders.



## New in v0.11.0 — Milestone 10 cost-aware paper execution

- Each prospective SMC observation receives an immutable snapshot of the execution assumptions that will be used for its simulation.
- Models next-eligible-candle-open entry after a configurable bar delay, fixed full-spread, per-side slippage and taker-fee assumptions on both sides, and a fixed quote-notional exposure. An optional deterministic entry-rejection stress rate is available; it is a scenario input, not a measured venue rejection probability.
- Stop exits use gap-aware reference prices (worse opening price when the market gaps through the stop); same-bar stop/target ambiguity remains stop-first. Target touches are assumed filled at the target with no price improvement, then adverse execution costs are applied.
- Stores entry/exit reference and modeled fill prices, gross P&L, spread cost, slippage cost, fee cost, total cost, net P&L, net return and net realized R.
- Adds execution ledger, assumption and performance-summary API endpoints plus dashboard metrics and per-observation execution details.
- Existing v0.10 observations are migrated with the current defaults and tagged `MIGRATED_DEFAULT`; they are not represented as having historical contemporaneous settings. Demo or non-Binance observations are blocked from cost-aware execution simulation.
- Results are still OHLC-based scenarios, not a broker emulator: spread/slippage are configured constants, candle touches cannot prove limit queue fills, partial fills/order-book impact/empirical entry or exit rejections are not modelled (optional entry-rejection stress is synthetic), and precise sub-candle latency is not available. Short trades are synthetic directional exposures and omit borrow, margin, liquidation and perpetual funding costs.
- Strict probability suppression and disabled live signal eligibility are unchanged; no exchange account, trading credential or order endpoint is used.

The exact acceptance policy is documented in [docs/research-validation.md](docs/research-validation.md).

## New in v0.13.0 — Milestone 12 mark-to-market and portfolio risk analytics

### Milestone 12 — mark-to-market portfolio risk (v0.13.0)

- Adds latest-closed-Binance-candle marks for currently open portfolio positions, with mark age and missing/stale status.
- Estimates unrealized P&L from portfolio-allocated quantity, frozen entry assumptions and estimated adverse exit spread/slippage plus two-sided fees. Marked equity is withheld unless every open position has a fresh mark.
- Adds synchronized-return Pearson correlation matrices for BTC/ETH/SOL by timeframe, with a 30-paired-return minimum, plus sample and annualized realized volatility.
- Adds instantaneous parallel underlying shocks from -10% to +10%, plus a deliberately conservative 2% adverse-to-each-position stress.
- Keeps realized equity and marked equity separate and explicitly labels all marks, correlations and stress outputs as research estimates rather than account values.

### Milestone 11 — portfolio capital and overlap simulation (v0.12.0)

- Combines eligible settled and currently open Binance-sourced paper executions across supported symbols/timeframes.
- Dynamically sizes each entry from current realized equity and its entry-to-stop distance, then applies per-position exposure, aggregate open-risk, gross-exposure and concurrent-position limits.
- Simultaneous entries share remaining gross-exposure and open-risk capacity pro rata. If concurrent-position slots are over-subscribed, deterministic symbol/timeframe/id ordering decides which candidate receives a slot.
- Entries are processed before exits at the same candle timestamp to avoid optimistic assumptions about intrabar ordering and capital reuse.
- Reports accepted/rejected entries and reasons, net realized P&L/return, win rate, profit factor, realized-equity curve/drawdown, peak/current exposure and open stop risk.
- Current open paper executions reserve capacity but are not included in realized P&L. The curve is realized-only and does not provide unrealized mark-to-market drawdown.
- Defaults: 10,000 USDT starting capital, 1% target risk budget per entry, 3% aggregate open-risk cap, 100% gross-exposure cap, 25% per-position exposure cap and three concurrent positions. Exposure caps can reduce actual risk below the target. All are hypothetical settings configurable in `backend/.env`.
- This is a research allocation overlay, not an account/margin simulator. Cross-asset correlation, margin, liquidation, borrow/funding and actual venue execution are not modelled. Strict probability suppression and disabled live-trading eligibility remain unchanged.


## v1.0.0 — Strategy Intelligence Engine

- Adds a deterministic, explainable multi-timeframe strategy hypothesis endpoint (`GET /api/v1/market/strategy/analyze`).
- Combines EMA20/EMA50 trend, RSI(14), ATR(14), relative volume, confirmed SMC structure, recent structure breaks, nearby open FVG candidates, recent liquidity sweeps and higher-timeframe SMC context.
- Adds relevant stored RSS headlines as non-directional context only. Heuristic news tags do not add directional score.
- Returns separate long/short confluence indices, evidence, opposing evidence, data provenance and reference invalidation/target levels when a setup passes the configurable-in-code score threshold.
- Evidence score is not a probability, calibrated confidence, forecast, or execution instruction. `validated_probability` is always null.
- Uses closed candles only and returns insufficient-data/no-clear-setup states rather than forcing a directional hypothesis.
- Adds a Strategy Intelligence dashboard panel with instrument/timeframe selection and manual refresh.

### Strategy endpoint

`GET /api/v1/market/strategy/analyze?symbol=BTCUSDT&intervals=15m,1h,4h&limit=300`

The first requested interval is the focus timeframe; subsequent intervals contribute higher-timeframe structure context. Supported symbols and intervals follow the configured candle provider. Minimum 60 closed candles per timeframe. The score is a bounded rule-confluence index, not a win probability. Entry/stop/target fields are reference levels derived from the latest closed candle and recent swing/ATR structure; they are not executable prices or orders.

## Important probability definition

A published probability means only:

> Estimated probability that the configured take-profit level is touched before the configured stop-loss level within the selected horizon, conditional on a historical SMC structure-break setup and the listed feature definition.

It is **not** a general probability that BTC/ETH/SOL will rise or fall, not a live market forecast in this milestone, and not a promise of net profitability. The label omits fees, spread, slippage, funding, borrow, market impact, taxes, outages, and latency. The separate strategy backtest models some costs but is still a simplified OHLC simulation.

## API endpoints

- `GET /api/v1/health`
- `GET /api/v1/news` — stored public RSS headlines with optional `asset` / `category` filters
- `GET /api/v1/news/status` — per-feed fetch status
- `POST /api/v1/news/refresh` — manual refresh (write API key required when configured)
- `GET /api/v1/news/{id}/market-reaction?symbol=BTCUSDT&interval=1h&window_bars=24` — descriptive pre/post closed-candle returns; not causal
- `GET /api/v1/market/stream` — AllTick WebSocket status, freshness and optional order-book snapshots
- `GET /api/v1/market/prices`
- `GET /api/v1/market/candles?symbol=BTCUSDT&interval=1h&limit=10000`
- `POST /api/v1/market/candles/backfill?symbol=BTCUSDT&interval=1h&limit=20000`
- `GET /api/v1/market/candles/status`
- `GET /api/v1/market/smc?symbol=BTCUSDT&interval=1h&limit=1000`
- `GET /api/v1/market/smc/multi-timeframe?symbol=BTCUSDT&intervals=15m,1h,4h&limit=1000`
- `GET /api/v1/market/backtest/smc?symbol=BTCUSDT&interval=1h&limit=10000`
- `GET /api/v1/market/research/walk-forward?symbol=BTCUSDT&interval=1h&limit=20000`
- `GET /api/v1/market/research/calibration?...` (compatibility alias to the same strict walk-forward policy)
- `POST /api/v1/market/research/paper/observe?symbol=BTCUSDT&interval=1h` (advance open observations and capture a latest-candle structure event)
- `GET /api/v1/market/research/paper/observations?symbol=BTCUSDT&interval=1h&limit=100`
- `GET /api/v1/market/research/paper/summary?symbol=BTCUSDT&interval=1h`
- `GET /api/v1/market/research/paper/automation/status`
- `GET /api/v1/market/research/paper/automation/runs?limit=20`
- `GET /api/v1/market/research/paper/executions?symbol=BTCUSDT&interval=1h&limit=100`
- `GET /api/v1/market/research/paper/executions/summary?symbol=BTCUSDT&interval=1h`
- `GET /api/v1/market/research/paper/executions/assumptions`
- `GET /api/v1/market/research/paper/portfolio/summary` — includes realized portfolio summary plus v0.13.0 mark-to-market, correlation, volatility and stress analytics (portfolio-wide by default; optional `symbol` / `interval` filters)
- `GET /api/v1/macro/overview`

Supported Binance Spot symbols: `BTCUSDT`, `ETHUSDT`, `SOLUSDT`.
Supported intervals: `15m`, `30m`, `1h`, `2h`, `4h`, `1d`.

## Run on Kali Linux

Use Python 3.10+ and Node.js 20+ (Node.js 22 LTS recommended). From the extracted project directory:

### Backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

API docs: http://127.0.0.1:8000/docs

### Frontend (second terminal)

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

Dashboard: http://localhost:3000

### Run tests (third terminal)

```bash
cd backend
source .venv/bin/activate
python -m pytest -q
```

## First research run

Use the dashboard's **Walk-Forward Probability Lab** and select an instrument, timeframe, and history size. Its first run requests paginated public candles and persists them locally. The **Paper Research Recorder** can be triggered manually or run by the optional scheduler. The scheduler is disabled by default; enable it with `PAPER_RECORDER_ENABLED=true` in `backend/.env`, keep `DATA_MODE=binance`, and run one Uvicorn worker. Monitor `GET /api/v1/market/research/paper/automation/status` and `/automation/runs`. Each cycle logs provider/data errors and refuses non-Binance or stale candle data. You can also run manual capture:

```bash
curl -X POST "http://127.0.0.1:8000/api/v1/market/candles/backfill?symbol=BTCUSDT&interval=1h&limit=20000"

curl "http://127.0.0.1:8000/api/v1/market/research/walk-forward?symbol=BTCUSDT&interval=1h&limit=20000" | python3 -m json.tool
```

If `probabilities_published` is `false`, this is intentional. Inspect `gate_failures` and fold/regime diagnostics. Do not lower thresholds to force a percentage. A successful historical research gate still does not authorize live signal probabilities.

## Free data and provider notes

- Binance public Spot market-data REST/WebSocket endpoints do not require API credentials. Data is exchange Spot data, not broker CFD pricing. Respect the exchange's current API limits and terms.
- No trading credentials, order placement, or withdrawal permissions are used.
- The free metals source in earlier milestones is indicative quote data, not historical OHLC candles. Gold/silver SMC backtesting is therefore not enabled by this release.
- The FRED broad trade-weighted USD series is a proxy and is not the ICE DXY benchmark. Treasury observations are periodic/daily, not tick feeds.
- News is sourced from allowlisted public RSS feeds when available; see the v0.15.0 limitations and source-status endpoint.

## Research limitations and operational policy

- v0.13.0 retains strict walk-forward gates, diagnostic model comparisons, scheduled prospective capture and cost-aware OHLC execution, and adds portfolio-level capital/overlap simulation. A passing historical result is still not live-signal eligibility. Prospective performance evidence, drift monitoring and a separate release review remain required before any live use.
- A minimum sample gate is a guardrail, not proof that the model generalises. The reliability table, Brier score, log loss, confidence interval, and test count must all be reviewed.
- One asset/timeframe sample may fail the gate. Pooling data across assets/timeframes requires explicit validation that the target and feature distributions are comparable.
- OHLC bars cannot reveal intrabar ordering. Same-bar stop/target is handled pessimistically.
- The current feature set is intentionally small and interpretable: directional break distance in ATR, candle body fraction, log relative volume, CHoCH indicator, and aligned three-candle FVG indicator. Each feature is computed using data available at signal time.
- No real-money trading should be considered from these research outputs. Live probability use is disabled by design. The v0.11.0 per-trade execution layer is an OHLC cost scenario, not broker-connected paper execution: it applies configured fee, spread and slippage assumptions but cannot model actual order-book fills, partial fills, order rejections, market impact, borrow, funding or sub-candle latency.

## License / dependency approach

This repository uses permissively available public market-data endpoints and free/open-source application dependencies. The newly added calibration and evaluation engine uses only Python's standard library. Verify each provider's live terms and regional access before deployment; “public endpoint” does not mean unrestricted redistribution or guaranteed uptime.


## Portfolio paper simulation (v0.13.0)

The paper execution ledger now feeds a portfolio-level capital simulation. It applies risk-based position sizing, open stop-risk and gross-exposure caps, a maximum concurrent position limit, and conservative overlapping-trade sequencing. Review it at `GET /api/v1/market/research/paper/portfolio/summary` or in the Paper Research Recorder dashboard panel. Defaults are documented in `INSTALL-KALI.md` and `backend/.env.example`.

The reported equity curve/drawdown is realized-only; it is not mark-to-market account equity. Correlation, margin, funding, borrow, liquidation, and real venue fills remain out of scope. Portfolio simulation is research-only; strict probability suppression and no-order safeguards remain in force.

### Operational reliability (v0.14.0)

- `GET /api/v1/health/diagnostics` reports database integrity/connectivity, WebSocket state, stored candle freshness and disk capacity.
- Optional Telegram and SMTP alerts are configured through environment variables; alerts are deduplicated and do not affect research calculations.
- Configure `API_ACCESS_KEY` to require `X-API-Key` on API write methods. `APP_ENV=production` requires this key at startup. A basic in-memory write limiter is intended for the supplied single-worker service.
- Run `python scripts_backup_db.py --destination ./backups --retain 14` from `backend/` for verified online SQLite backups.
- `deploy/` contains systemd and Caddy examples. See `INSTALL-KALI.md` for setup, backup restore, and VPS hardening details.


### News intelligence limitations (v0.15.0)

RSS ingestion depends on publisher availability, rate limits and source timestamps. A successful fetch does not independently verify an article's claims. Keyword classification can miss context, negation, sarcasm and related assets; the importance label is only a review-priority heuristic. The event window uses stored closed-candle close prices and can have sparse or missing coverage. Pre/post returns are descriptive temporal associations, not causal effects or event-study alpha. No live probabilities, automated news trading or order execution is enabled.


## AllTick market-data provider (optional)

MarketMind AI v0.17.0 adds opt-in AllTick WebSocket trade-tick and order-book streaming alongside the REST adapter and K-line history. The provider token is stored only in the backend environment; never place it in frontend variables or commit it.

1. Register at https://alltick.co/register and copy the API key from the account dashboard.
2. Set `DATA_MODE=alltick` and `ALLTICK_API_KEY=...` in `backend/.env`.
3. Restart the API and inspect `/api/v1/market/prices` and `/api/v1/market/candles/status`.

The adapter maps BTCUSDT to `BTCUSDT`, XAUUSD to `GOLD`, and XAGUSD to `Silver`. ETHUSDT and SOLUSDT are configured as expected product codes but their availability must be confirmed in the AllTick product list/account. AllTick's repository documents the forex/crypto/metals REST base `/quote-b-api/v1`, the `X-API-Key` header, latest quote batch `/quote`, and K-line `/kline/{query}`. It documents 1-minute through monthly K-line types and a 500-record maximum per K-line request.

The free-tier documentation states a 10-second per-request interval, up to five products in a quote batch, and 1,000 requests per day. To stay below that daily ceiling before manual history queries, MarketMind defaults to a 90-second quote polling interval. The local request guard also enforces at least 10 seconds between calls and a 1,000-call daily process budget. This is a conservative local guard, not a provider-side quota meter; multiple applications sharing one token can exceed the provider quota.

**Important limitations:** this milestone uses REST polling, not a live AllTick WebSocket stream. The repository documents WebSocket transaction/depth subscriptions but says K-line push is not supported. Latest quote responses do not provide 24-hour percentage change in the documented schema, so MarketMind reports that field as unavailable. K-line volume/turnover fields are normalized; trades and taker-buy volume are not provided and are stored as zero. AllTick data is provider-supplied and may not match a broker's CFD quote, spread, or executable price. No authenticated live call can be verified until you configure your own token and confirm product entitlements.

Switch back to `DATA_MODE=binance` to use the existing Binance crypto feed and XAUS metals feed. The AllTick token is not required for Binance or demo mode.



## AllTick WebSocket streaming (v0.17.0)

AllTick streaming is opt-in and requires `DATA_MODE=alltick`, a valid `ALLTICK_API_KEY`, and `ALLTICK_WS_ENABLED=true`. The worker uses the documented forex/crypto/metals endpoint `wss://quote.alltick.co/quote-b-ws-api`, subscribes to one mode per connection (`trade` or `depth`), sends the provider application heartbeat every 10 seconds, and reconnects with bounded exponential backoff. The default subscription is BTCUSDT, XAUUSD (`GOLD`) and XAGUSD (`Silver`). The free-tier documentation lists one WebSocket connection and up to five products per subscription; confirm current account limits before enabling.

AllTick's documentation says trade tick pushes use command 22998 and order-book pushes use 22999; K-line push is explicitly marked unsupported. Historical candles therefore remain on the REST K-line endpoint. `GET /api/v1/market/stream` reports connection, message, error, freshness and order-book diagnostics. `GET /api/v1/market/prices` uses stream ticks when WebSocket mode is enabled. A quiet feed is marked stale/reconnected; this is not a guarantee of market coverage or executable quotes.

The AllTick token is passed only server-side over TLS. Do not expose it in frontend configuration. WebSocket credentials and product entitlements were not live-verified in this build because no token was supplied.


### Cross-provider data quality (v0.18.0)

When `DATA_MODE=alltick`, MarketMind can run independent Binance Spot crypto and XAUS indicative metals reference feeds. It compares fresh AllTick observations against those references and stores sampled AllTick ticks/order-book midpoints in a bounded SQLite table. Use `/api/v1/market/data-quality`, `/api/v1/market/data-quality/comparisons`, and `/api/v1/market/data-quality/observations` to inspect results. The comparisons are diagnostic only: crypto spot venues can differ and XAUS metals quotes are indicative, not executable broker prices. Provider-specific OHLC histories are not merged. Configure `DATA_QUALITY_ENABLED`, `DATA_QUALITY_POLL_SECONDS`, `TICK_STORAGE_ENABLED`, `TICK_STORAGE_MIN_INTERVAL_SECONDS`, and `TICK_STORAGE_RETENTION_DAYS` in `.env`.


## v0.19.0 — Execution microstructure research

- Added order-book snapshot analytics: bid/ask spread, top-five depth, quantity imbalance, microprice deviation and visible depth within 10/25 bps.
- Added deterministic buy/sell visible-depth sweep estimates using the latest stored AllTick order-book snapshot, including VWAP, slippage versus mid, visible fill ratio and unfilled quantity.
- Added historical snapshot metrics and dashboard panel.
- Requires `DATA_MODE=alltick`, `ALLTICK_WS_ENABLED=true`, `ALLTICK_WS_SUBSCRIPTION=depth`, and `TICK_STORAGE_ENABLED=true`. AllTick trade and depth subscriptions are mutually exclusive on one connection.
- Estimates are snapshot diagnostics, not fills; they exclude fees, latency during execution, queue priority, hidden liquidity, cancellations and impact beyond displayed depth.
